import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Helmet } from 'react-helmet';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Toaster } from '@/components/ui/toaster';
import { useToast } from '@/components/ui/use-toast';
import { Clock, Mail, Star, Sparkles, Rocket, Bell } from 'lucide-react';

function App() {
  const [email, setEmail] = useState('');
  const { toast } = useToast();

  const getLaunchDate = () => {
    let storedLaunchDate = localStorage.getItem('launchDate');
    if (!storedLaunchDate) {
      const newLaunchDate = new Date();
      newLaunchDate.setDate(newLaunchDate.getDate() + 30);
      storedLaunchDate = newLaunchDate.toISOString();
      localStorage.setItem('launchDate', storedLaunchDate);
    }
    return new Date(storedLaunchDate);
  };

  const [launchDate] = useState(getLaunchDate());

  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  });

  useEffect(() => {
    const calculateTimeLeft = () => {
      const now = new Date().getTime();
      const distance = launchDate.getTime() - now;

      if (distance > 0) {
        return {
          days: Math.floor(distance / (1000 * 60 * 60 * 24)),
          hours: Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
          minutes: Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60)),
          seconds: Math.floor((distance % (1000 * 60)) / 1000)
        };
      }
      return { days: 0, hours: 0, minutes: 0, seconds: 0 };
    };
    
    setTimeLeft(calculateTimeLeft());

    const timer = setInterval(() => {
      setTimeLeft(calculateTimeLeft());
    }, 1000);

    return () => clearInterval(timer);
  }, [launchDate]);

  const handleEmailSubmit = (e) => {
    e.preventDefault();
    if (email) {
      const emails = JSON.parse(localStorage.getItem('comingSoonEmails') || '[]');
      if (!emails.includes(email)) {
        emails.push(email);
        localStorage.setItem('comingSoonEmails', JSON.stringify(emails));
        toast({
          title: "🎉 You're on the list!",
          description: "We'll notify you as soon as we launch!",
        });
        setEmail('');
      } else {
        toast({
          title: "Already subscribed!",
          description: "You're already on our launch notification list.",
        });
      }
    } else {
      toast({
        title: "Email required",
        description: "Please enter your email address to get notified.",
        variant: "destructive"
      });
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        delayChildren: 0.3,
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.8,
        ease: "easeOut"
      }
    }
  };

  return (
    <>
      <Helmet>
        <title>Coming Soon - Something Amazing is Loading!</title>
        <meta name="description" content="We're building something incredible! Join our waitlist to be the first to know when we launch." />
      </Helmet>
      
      <div className="min-h-screen relative overflow-hidden flex flex-col">
        {/* Animated Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(120,119,198,0.3),transparent_50%)]"></div>
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_20%,rgba(120,119,198,0.2),transparent_50%)]"></div>
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_80%,rgba(120,119,198,0.2),transparent_50%)]"></div>
        </div>

        {/* Floating Elements */}
        <motion.div
          className="absolute top-20 left-10 text-purple-300/30"
          animate={{
            y: [0, -20, 0],
            rotate: [0, 5, 0]
          }}
          transition={{
            duration: 4,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          <Sparkles size={40} />
        </motion.div>

        <motion.div
          className="absolute top-40 right-20 text-blue-300/30"
          animate={{
            y: [0, 20, 0],
            rotate: [0, -5, 0]
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 1
          }}
        >
          <Star size={30} />
        </motion.div>

        <motion.div
          className="absolute bottom-40 left-20 text-indigo-300/30"
          animate={{
            y: [0, -15, 0],
            rotate: [0, 10, 0]
          }}
          transition={{
            duration: 5,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 2
          }}
        >
          <Rocket size={35} />
        </motion.div>

        {/* Main Content */}
        <main className="relative z-10 flex-grow flex items-center justify-center p-4">
          <motion.div
            className="text-center max-w-4xl mx-auto"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
          >
            {/* Logo/Icon */}
            <motion.div
              variants={itemVariants}
              className="mb-8"
            >
              <div className="inline-flex items-center justify-center w-24 h-24 bg-gradient-to-br from-purple-500 to-blue-600 rounded-full mb-6 shadow-2xl">
                <Rocket className="w-12 h-12 text-white" />
              </div>
            </motion.div>

            {/* Main Heading */}
            <motion.h1
              variants={itemVariants}
              className="text-5xl md:text-7xl font-bold bg-gradient-to-r from-purple-400 via-pink-400 to-blue-400 bg-clip-text text-transparent mb-6"
            >
              Coming Soon
            </motion.h1>

            {/* Subtitle */}
            <motion.p
              variants={itemVariants}
              className="text-xl md:text-2xl text-gray-300 mb-12 max-w-2xl mx-auto leading-relaxed"
            >
              We're crafting something extraordinary that will revolutionize your experience. 
              <span className="text-purple-400 font-semibold"> Get ready to be amazed!</span>
            </motion.p>

            {/* Countdown Timer */}
            <motion.div
              variants={itemVariants}
              className="mb-12"
            >
              <div className="flex items-center justify-center mb-6">
                <Clock className="w-6 h-6 text-purple-400 mr-2" />
                <span className="text-lg text-gray-300">Launch Countdown</span>
              </div>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-lg mx-auto">
                {[
                  { label: 'Days', value: timeLeft.days },
                  { label: 'Hours', value: timeLeft.hours },
                  { label: 'Minutes', value: timeLeft.minutes },
                  { label: 'Seconds', value: timeLeft.seconds }
                ].map((item, index) => (
                  <motion.div
                    key={item.label}
                    className="bg-white/10 backdrop-blur-lg rounded-xl p-4 border border-white/20"
                    whileHover={{ scale: 1.05 }}
                    transition={{ duration: 0.2 }}
                  >
                    <div className="text-2xl md:text-3xl font-bold text-white">
                      {String(item.value).padStart(2, '0')}
                    </div>
                    <div className="text-sm text-gray-300 uppercase tracking-wide">
                      {item.label}
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>

            {/* Email Signup */}
            <motion.div
              variants={itemVariants}
              className="mb-12"
            >
              <div className="flex items-center justify-center mb-6">
                <Bell className="w-6 h-6 text-purple-400 mr-2" />
                <span className="text-lg text-gray-300">Be the first to know</span>
              </div>
              
              <form onSubmit={handleEmailSubmit} className="max-w-md mx-auto">
                <div className="flex flex-col sm:flex-row gap-3">
                  <div className="flex-1">
                    <Input
                      type="email"
                      placeholder="Enter your email address"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="bg-white/10 backdrop-blur-lg border-white/20 text-white placeholder:text-gray-400 h-12"
                    />
                  </div>
                  <Button
                    type="submit"
                    className="bg-gradient-to-r from-purple-500 to-blue-600 hover:from-purple-600 hover:to-blue-700 text-white font-semibold h-12 px-8 shadow-lg hover:shadow-xl transition-all duration-300"
                  >
                    <Mail className="w-4 h-4 mr-2" />
                    Notify Me
                  </Button>
                </div>
              </form>
            </motion.div>

            {/* Features Preview */}
            <motion.div
              variants={itemVariants}
              className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-3xl mx-auto"
            >
              {[
                {
                  icon: <Sparkles className="w-8 h-8" />,
                  title: "Revolutionary Features",
                  description: "Experience cutting-edge functionality like never before"
                },
                {
                  icon: <Star className="w-8 h-8" />,
                  title: "Premium Quality",
                  description: "Built with attention to every detail and user experience"
                },
                {
                  icon: <Rocket className="w-8 h-8" />,
                  title: "Lightning Fast",
                  description: "Optimized performance that exceeds expectations"
                }
              ].map((feature, index) => (
                <motion.div
                  key={index}
                  className="bg-white/5 backdrop-blur-lg rounded-xl p-6 border border-white/10"
                  whileHover={{ 
                    scale: 1.05,
                    backgroundColor: "rgba(255, 255, 255, 0.1)"
                  }}
                  transition={{ duration: 0.3 }}
                >
                  <div className="text-purple-400 mb-4 flex justify-center">
                    {feature.icon}
                  </div>
                  <h3 className="text-lg font-semibold text-white mb-2">
                    {feature.title}
                  </h3>
                  <p className="text-gray-300 text-sm">
                    {feature.description}
                  </p>
                </motion.div>
              ))}
            </motion.div>
          </motion.div>
        </main>

        {/* Footer */}
        <footer className="relative z-10 p-6 text-center">
          <p className="text-gray-400 text-sm">
            © 2025 AZ Empire. Something amazing is on the way.
          </p>
        </footer>
      </div>
      
      <Toaster />
    </>
  );
}

export default App;